#include<iostream>
#include<string>
#include<vector>
#include "queue.cpp"
#include "map.cpp"
using namespace std;
void print_order3(combo* c){
    for(int i=0;i<c->pairs.capacity;i++){
        LL<KeyValue<string,int>> temp=c->pairs.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            cout<<curr->key<<" "<<curr->value<<" ";
            curr=curr->next;
        }
    }
    if(c->tradeType=='b')
        cout<<c->price<<" "<<c->true_arbit_qty<<" s"<<endl;
    else
        cout<<c->price<<" "<<c->true_arbit_qty<<" b"<<endl;
    c->qty -= c->true_arbit_qty;
    c->true_arbit_qty=0;
}
bool cancel3(Queue &pending3){
    if(pending3.front==pending3.rear) return false;
    combo*curr=pending3.front;
    combo*to_be=pending3.rear;
    while(curr!=to_be){
        if(compareCustomUnorderedMaps(curr->pairs,to_be->pairs) && curr->price==to_be->price){
            if(curr->tradeType==to_be->tradeType){
                to_be->qty+=curr->qty;
                pending3.deletecombo(curr);
                return false;    
            }
            else{
                to_be->qty-=curr->qty;
                pending3.deletecombo(curr);
                if(to_be->qty==0) {
                    pending3.deletecombo(to_be);
                    return true;
                }
                return false;
            }
        }
        curr=curr->next;
    }
    return false;
}
bool check3(CustomUnorderedMap<string,int> &allStocks){
    for(int i=0;i<allStocks.capacity;i++){
        LL<KeyValue<string,int>> temp=allStocks.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            if(curr->value!=0){
                return false;
            }
            curr=curr->next;
        }
    }
    return true;
}
void helper3(Queue& pending3,CustomUnorderedMap<string,int> &allStocks,int&maxPriceSum,int &priceSum,combo* current,vector<combo*>&PriceCombo,vector<combo*>& arbitrage_orders3){
    if(current==NULL) return;
    for(int j=0;j<=current->qty;j++){
        current->arbit_qty=j;
        if(j!=0){
            for(int i=0;i<current->pairs.capacity;i++){
                LL<KeyValue<string,int>> temp=current->pairs.table[i];
                auto curr=temp.head;
                while(curr!=NULL){
                    if(current->tradeType=='b') allStocks[curr->key]+=curr->value;
                    else allStocks[curr->key]-=curr->value;
                    curr=curr->next;
                }
            }
            if(current->tradeType=='b') priceSum+=current->price;
            else priceSum-=current->price;
        }    
        if(j==1)PriceCombo.push_back(current);
        helper3(pending3,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders3);
        //checking if a arbitrage is formed
        if(!PriceCombo.empty() && check3(allStocks)){   
            if(priceSum > maxPriceSum){
                arbitrage_orders3=PriceCombo;
                maxPriceSum=priceSum;
                for(auto x:arbitrage_orders3){
                    x->true_arbit_qty=x->arbit_qty;
                }
            }
        }
        // else helper3(pending3,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders3);
    }
            for(int i=0;i<current->pairs.capacity;i++){
                    LL<KeyValue<string,int>> temp=current->pairs.table[i];
                    auto curr=temp.head;
                    while(curr!=NULL){
                        if(current->tradeType=='s'){
                            allStocks[curr->key]+=curr->value*current->qty;
                            if(allStocks[curr->key]==0) allStocks.erase(curr->key);
                        }
                        else{
                            allStocks[curr->key]-=curr->value*current->qty;
                            if(allStocks[curr->key]==0) allStocks.erase(curr->key);
                        }
                        curr=curr->next;
                    }
                }
            if(current->tradeType=='s')
                priceSum+=current->price*current->qty;
            else
                priceSum-=current->price*current->qty;
            current->arbit_qty=0;
            // helper3(pending3,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders3);
            PriceCombo.pop_back();
    return;
}
bool arbitrage_check3(Queue& pending3, vector<combo*>& arbitrage_orders3,int& profit3) {
    if(pending3.isEmpty()) return false; 
    if(pending3.front==pending3.rear) return false;
    int maxPriceSum = 0;  // Initialize maximum sum of prices to 0.
    int priceSum=0;
    vector<combo*> PriceCombo;  // Initialize a vector to store orders with price sum.

    combo* current = pending3.front;
    CustomUnorderedMap<string,int> allStocks;
    helper3(pending3,allStocks,maxPriceSum,priceSum,pending3.front,PriceCombo,arbitrage_orders3);
    profit3+=maxPriceSum;
    return !arbitrage_orders3.empty();
}
int profit3=0;
Queue pending3;
void func3(string &message){
            istringstream messageStream(message);
            string inputLine;
            while (getline(messageStream, inputLine, '#')){
                if(inputLine.empty() || inputLine.find('$')!=string::npos){
                    cout<<profit3<<endl;
                    break;
                }
                
                istringstream isss(inputLine); // Create a string stream to parse the line
                string stockName;
                int quantity;
                int qty_order;
                double price;
                char tradeType;
                int wordcount=0;
                while(isss>>stockName) wordcount++;
                istringstream iss(inputLine);
                CustomUnorderedMap<string,int>temp;

                // Read stock names and quantities until the price is reached
                for(int i=0;i<wordcount-3;i+=2){
                    iss >> stockName >> quantity;
                    temp[stockName]=quantity;
                }
                iss>> price >> qty_order >> tradeType;

                if(stockName.empty()) break; // pipe error resolve
                
                temp.sortLists();
                pending3.enqueue(temp,tradeType,price,qty_order);
                bool iscancel=cancel3(pending3);
                vector<combo*> arbitrage_orders3;
                bool d=arbitrage_check3(pending3,arbitrage_orders3,profit3);
                if(!iscancel && d){
                    for(int i=arbitrage_orders3.size()-1;i>=0;i--){
                        print_order3(arbitrage_orders3[i]);
                    }
                }
                else{
                    cout<<"No Trade"<<endl;
                }
            }
}