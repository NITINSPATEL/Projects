#ifndef MY_HEADER3_H
#define MY_HEADER3_H
#include <iostream>
#include <vector>
#include<string>
using namespace std;
// Define a custom pair to hold key-value pairs
template <typename K, typename V>
struct KeyValue {
    K key;
    V value;
    KeyValue* next;
    KeyValue(){
        key="";
        value=0;
    }
    KeyValue(const K& k, const V& v){
        key=k; 
        value=v;
        next=NULL;
    }
    void print(){
        cout<<"Name :"<<key<<"Value: " <<value<<endl;
    }
        
};
template<typename T>
class LL{public:
    T* head;
    T* tail;
    int size;
    LL(){
        head=tail=NULL;
        size=0;
    }
    void insert(string n,int c){
        T*new_node=new T(n,c);
        if(head==NULL){
            head=tail=new_node;
            size++;
            return;
        }
        tail->next=new_node;
        tail=new_node;
        size++;
    }
    T* find(string n){
        T*curr=head;
        while(curr!=NULL){
            if(curr->key==n){
                return curr;
            }
            curr=curr->next;
        }
        return NULL;
    }
    void del(string k){
        if(head==NULL) return;
        T*curr=head;
        if(curr->key==k){
            if(head==tail){
                delete(head);
                size--;
                head=tail=NULL;
                return;
            }
            delete(head);
            size--;
            head=curr->next;
            return;
        }
        while(curr!=NULL && curr->next!=NULL){
            if(curr->next->key==k){
                T*to_be=curr->next;
                curr->next=to_be->next;
                if(to_be==tail){
                    tail=curr;
                }
                delete(to_be);
                size--;
                break;
            }
            curr=curr->next;
        }
    }
    void prin(){
        T*curr=head;
        while(curr!=NULL){
            curr->print();
            curr=curr->next;
        }
    }
    void sort() {
        if (size <= 1) {
            return; // No need to sort if there's only 1 or 0 elements
        }

        head = mergeSort(head);
        T* temp = head;
        while (temp->next) {
            temp = temp->next;
        }
        tail = temp;
    }

private:
    T* merge(T* left, T* right) {
        if (!left) {
            return right;
        }
        if (!right) {
            return left;
        }

        T* result;
        if (left->key <= right->key) {
            result = left;
            result->next = merge(left->next, right);
        } else {
            result = right;
            result->next = merge(left, right->next);
        }
        return result;
    }

    T* mergeSort(T* head) {
        if (!head || !head->next) {
            return head;
        }

        T* middle = getMiddle(head);
        T* nextToMiddle = middle->next;
        middle->next = nullptr;

        T* left = mergeSort(head);
        T* right = mergeSort(nextToMiddle);

        return merge(left, right);
    }

    T* getMiddle(T* head) {
        T* slow = head;
        T* fast = head;
        while (fast->next && fast->next->next) {
            slow = slow->next;
            fast = fast->next->next;
        }
        return slow;
    }
};

template <typename K, typename V>
class CustomUnorderedMap {
public:
    std::vector<LL<KeyValue<K, V>>> table;
    size_t capacity;

    // A simple hash function for string keys
    size_t hash(const K& key) {
        std::hash<string> hasher;
        return hasher(key) % capacity;
    }

    CustomUnorderedMap(size_t initialCapacity = 64){
        capacity=initialCapacity;
        table.resize(capacity);
        for(int i=0;i<capacity;i++){
            table[i].head = table[i].tail = NULL;
        }
    }

    // Insert a key-value pair into the map
    void insert(const K& key, const V& value) {
        size_t index = hash(key);
        auto x=table[index].find(key);
        if(x!=NULL){
            x->value=value;
            return;
        }
        table[index].insert(key, value);
    }

    // Retrieve the value associated with a key
    V& operator[](const K& key) {
        size_t index = hash(key);
        auto x=table[index].find(key);
        if(x==NULL){
            // If key doesn't exist, insert a new key-value pair
            insert(key, V());
            return table[index].tail->value;
        }
        else{
            return x->value;
        }
    }

    // Check if a key exists in the map
    bool contains(const K& key) {
        size_t index = hash(key);
        if(table[index].find(key)==NULL)
            return false;
        else return true;
    }

    // Remove a key-value pair from the map
    void erase(const K& key) {
        size_t index = hash(key);
        table[index].del(key);
    }
    void sortLists() {
        for (LL<KeyValue<K, V>>& linkedList : table) {
            linkedList.sort();
        }
    }
};
template <typename K, typename V>
bool compareCustomUnorderedMaps(const CustomUnorderedMap<K, V>& map1, const CustomUnorderedMap<K, V>& map2) {
    // Iterate through each bucket in both maps
    for (size_t index = 0; index < map1.capacity; ++index) {
        // Check if the size of the linked list in each bucket is the same
        if(map1.table[index].size!=map2.table[index].size) return false;
        // Iterate through each node in the linked list
        auto node1 = map1.table[index].head;
        auto node2 = map2.table[index].head;
        while (node1 != nullptr && node2 != nullptr) {
            // Check if the keys and values match
            if (node1->key != node2->key || node1->value != node2->value) {
                return false;
            }
            node1 = node1->next;
            node2 = node2->next;
        }
        if (node1 != nullptr || node2 != nullptr) {
            return false;
        }
    }

    // If all checks passed, the maps are equal
    return true;
}
#endif // MY_HEADER3_H