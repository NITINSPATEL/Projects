#ifndef MY_HEADER2_H
#define MY_HEADER2_H
#include<vector>
#include<string>
#include "map.cpp"
using namespace std;
class combo{public:
    CustomUnorderedMap<string,int> pairs;
    char tradeType;
    int price;
    int qty;
    int arbit_qty;
    int true_arbit_qty;
    combo* next;
    combo(){next=NULL;}
    combo(CustomUnorderedMap<string,int>&m, char type, int p,int q=0,int q1=0) {
        pairs=m;
        tradeType = type;
        price = p;
        qty=q;
        arbit_qty=q1;
        next = NULL;
    }
};
class Queue{public:
    combo* front;
    combo* rear;
    int size;
    Queue() {
        front = rear = NULL;
        size=0;
    }
    bool isEmpty(){
        return front == NULL;
    }
    void enqueue(CustomUnorderedMap<string,int>&m, char type, int p,int q=0,int q1=0) {
        combo* newCombo = new combo(m, type, p,q,q1);
        if (isEmpty()) front = rear = newCombo;
        else {
            rear->next = newCombo;
            rear = newCombo;
        }
        size++;
    }
    
    void deletecombo(combo*to_be) {
        if (isEmpty()) return;
        combo* current = front;
        combo* prev = NULL;
        while (current != NULL && current!= to_be) { // Assuming stockNames[0] contains the stock name
            prev = current;
            current = current->next;
        }
        if (current == NULL) return;                         // Node not found
        if (current == front) front = current->next;
        else prev->next = current->next;
        if (current == rear) rear = prev;
        delete current;
        size--;
    }
};
void print_order(combo* c){
    for(int i=0;i<c->pairs.capacity;i++){
        LL<KeyValue<string,int>> temp=c->pairs.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            cout<<curr->key<<" "<<curr->value<<" ";
            curr=curr->next;
        }
    }
    if(c->tradeType=='b')
        cout<<c->price<<" s"<<endl;
    else
        cout<<c->price<<" b"<<endl;
}
bool cancel(Queue &pending2){
    if(pending2.front==pending2.rear) return false;
    combo*curr=pending2.front;
    combo*to_be=pending2.rear;
    while(curr!=to_be){
        if(compareCustomUnorderedMaps(curr->pairs,to_be->pairs)){
            if(curr->tradeType==to_be->tradeType){
                if(to_be->tradeType=='s'){
                    if(curr->price <= to_be->price) {
                        pending2.deletecombo(to_be);
                        return true;
                    }
                    else {
                        combo * t=curr;
                        curr=curr->next;
                        pending2.deletecombo(t);
                        continue;
                    }
                }
                else{
                    if(curr->price >= to_be->price) {
                        pending2.deletecombo(to_be);
                        return true;
                    }
                    else {
                        combo*t=curr;
                        curr=curr->next;
                        pending2.deletecombo(t);
                        continue;
                    }
                }
            }
            if(curr->tradeType!=to_be->tradeType && curr->price==to_be->price){
                pending2.deletecombo(to_be);
                pending2.deletecombo(curr);
                return true;
            }
        }
        curr=curr->next;
    }
    return false;
}
bool check(CustomUnorderedMap<string,int> &allStocks){
    for(int i=0;i<allStocks.capacity;i++){
        LL<KeyValue<string,int>> temp=allStocks.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            if(curr->value!=0){
                return false;
            }
            curr=curr->next;
        }
    }
    return true;
}
void helper(Queue& pending2,CustomUnorderedMap<string,int> &allStocks,int&maxPriceSum,int &priceSum,combo* current,vector<combo*>&PriceCombo,vector<combo*>& arbitrage_orders){
    if(current==NULL) return;

    for(int i=0;i<current->pairs.capacity;i++){
        LL<KeyValue<string,int>> temp=current->pairs.table[i];
        auto curr=temp.head;
        while(curr!=NULL){
            if(current->tradeType=='b')
                allStocks[curr->key]+=curr->value;
            else
                allStocks[curr->key]-=curr->value;
            curr=curr->next;
        }
    }
    if(current->tradeType=='b')
        priceSum+=current->price;
    else
        priceSum-=current->price;
    PriceCombo.push_back(current);
    //checking if a arbitrage is formed
    if(!PriceCombo.empty() && check(allStocks)){   
        if(priceSum > maxPriceSum){
            arbitrage_orders=PriceCombo;
            maxPriceSum=priceSum;
        }
    }
    else
        helper(pending2,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders);
    
    // current=*PriceCombo.rbegin();
    for(int i=0;i<current->pairs.capacity;i++){
            LL<KeyValue<string,int>> temp=current->pairs.table[i];
            auto curr=temp.head;
            while(curr!=NULL){
                if(current->tradeType=='s')
                    allStocks[curr->key]+=curr->value;
                else
                    allStocks[curr->key]-=curr->value;
                curr=curr->next;
            }
        }
    PriceCombo.pop_back();
    if(current->tradeType=='s')
        priceSum+=current->price;
    else
        priceSum-=current->price;
    helper(pending2,allStocks,maxPriceSum,priceSum,current->next,PriceCombo,arbitrage_orders);
    return;
}
bool arbitrage_check(Queue& pending2, vector<combo*>& arbitrage_orders,int& profit) {
    if(pending2.isEmpty()) return false; 
    if(pending2.front==pending2.rear) return false;
    int maxPriceSum = 0;  // Initialize maximum sum of prices to 0.
    int priceSum=0;
    vector<combo*> PriceCombo;  // Initialize a vector to store orders with price sum.

    combo* current = pending2.front;
    CustomUnorderedMap<string,int> allStocks;
    helper(pending2,allStocks,maxPriceSum,priceSum,pending2.front,PriceCombo,arbitrage_orders);
    profit+=maxPriceSum;
    return !arbitrage_orders.empty();
}
int profit=0;
Queue pending2;
void func2(string &message){
            istringstream messageStream(message);
            string inputLine;
            while (getline(messageStream, inputLine, '#')){
                if(inputLine.empty() || inputLine.find('$')!=string::npos){
                    cout<<profit<<endl;
                    break;
                }
                
                istringstream isss(inputLine); // Create a string stream to parse the line
                string stockName;
                int quantity;
                double price;
                char tradeType;
                int wordcount=0;
                while(isss>>stockName) wordcount++;
                istringstream iss(inputLine);
                CustomUnorderedMap<string,int>temp;

                // Read stock names and quantities until the price is reached
                for(int i=0;i<wordcount-2;i+=2){
                    iss >> stockName >> quantity;
                    temp[stockName]=quantity;
                }
                iss>> price >> tradeType;

                if(stockName.empty()) break; // pipe error resolve

                temp.sortLists();
                pending2.enqueue(temp,tradeType,price);

                bool iscancel=cancel(pending2);
                vector<combo*> arbitrage_orders;
                bool d=arbitrage_check(pending2,arbitrage_orders,profit);
                if(!iscancel && d){
                    for(int i=arbitrage_orders.size()-1;i>=0;i--){
                        print_order(arbitrage_orders[i]);
                        pending2.deletecombo(arbitrage_orders[i]);
                    }
                }
                else{
                    cout<<"No Trade"<<endl;
                }
            }
}
#endif // MY_HEADER_H