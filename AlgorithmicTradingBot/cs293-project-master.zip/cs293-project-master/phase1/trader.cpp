#ifndef MY_HEADER_H
#define MY_HEADER_H
#include "receiver.h"
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "Linked_list.cpp"
#include "queue.cpp"
#include "part3.cpp"
using namespace std;
int main(int argc,char **argv){
    Receiver rcv;
    string message;
    bool found=false;
    while(!found){
        // Receive the message from the Receiver
        message = rcv.readIML();
        if(message.find('$')!=string::npos){
            rcv.terminate();
            found=true;
        }
        if(*argv[1]=='1') func1(message);
        else if(*argv[1]=='2'){
            func2(message);
        }
        else if(*argv[1]=='3'){
            func3(message);
        }
        else{
            cout<<"Error"<<endl;
        }
    }
    return 0;
}
#endif // MY_HEADER_H
