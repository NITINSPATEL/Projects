#include <string>
using namespace std;
class node{public:
    node* next;
    string name;
    int cost,ords,ordb;
    bool is_valid_ordb,is_valid_ords;
    node(string n,int c){
        name=n;
        cost=c;
        ords=ordb=0;
        is_valid_ordb=is_valid_ords=0;
        next=NULL;
    }
};
class LL1{public:
    node*head;
    node*tail;
    LL1(){
        head=tail=NULL;
    }
    void insert(string n,int c){
        node*new_node=new node(n,c);
        if(head==NULL){
            head=tail=new_node;
            return;
        }
        tail->next=new_node;
        tail=new_node;
    }
    node* find(string n){
        node*curr=head;
        while(curr!=NULL){
            if(curr->name==n){
                return curr;
            }
            curr=curr->next;
        }
        return NULL;
    }
    void update(node* to_be,int p){
        to_be->cost=p;
    }
};
LL1 ll; 
void func1(string &message){
    istringstream messageStream(message);
    string line;
    // if(message.empty()) return;
    // Split the message into individual lines (lines end with #)    
    
    while (getline(messageStream, line, '#')) {
            // Remove leading and trailing whitespace
        if (!line.empty() && line.find('$') == string::npos) {         
            // Process each line and make trading decisions
            istringstream iss(line);
            string stock_name;
            double price;
            char trade_type;
            iss >> stock_name >> price >> trade_type;
            
            if(stock_name.empty()) break;   // thoda pipe error resolve krna
            
            node* node_found=ll.find(stock_name);                    
            // Make trading decisions based on trade_type
            if (trade_type == 'b'){
                // Buy the stock if the price is lower than your estimate
                if(node_found==NULL){
                    cout<< stock_name << " " << price << " s" << endl;
                    ll.insert(stock_name,price);
                }
                else{
                    bool iscancel=false;
                    if(node_found->is_valid_ordb ==1 && node_found->ordb < price) node_found->is_valid_ordb=0;
                    else if(node_found->is_valid_ordb==1 && node_found->ordb >= price) iscancel=true;
                    
                    if(node_found->is_valid_ords==1 && node_found->ords==price && iscancel==false){
                        node_found->is_valid_ords=0;
                        iscancel=true;
                    }
                    // cerr<<"name "<<node_found->name<< " ords " << node_found->ords << " ordb " << node_found->ordb<<endl;
                    
                    if(iscancel==false)
                    {
                        if(node_found->cost < price){
                            cout<< stock_name << " " << price << " s" << endl;
                            ll.update(node_found,price);
                        }
                        else{
                            node_found->is_valid_ordb=1;
                            node_found->ordb=price;
                            cout<<"No Trade"<<endl;
                        }
                    }
                    else cout<<"No Trade"<<endl;
                }
            } 
            else if (trade_type == 's') {
                // Sell the stock if the price is higher than your estimate
                if(node_found==NULL){
                    cout<< stock_name << " " << price << " b" << endl;
                    ll.insert(stock_name,price);
                }
                else{
                    bool iscancel=false;
                    if(node_found->is_valid_ords==1 && node_found->ords > price) node_found->is_valid_ords=0;
                    else if(node_found->is_valid_ords ==1 && node_found->ords <= price) iscancel=true;
                    
                    if(node_found->is_valid_ordb==1 && node_found->ordb==price && iscancel==false){
                        node_found->is_valid_ordb=0;
                        iscancel=true;
                    }
                    // cerr<<"name "<<node_found->name<< " ords " << node_found->ords << " ordb " << node_found->ordb<<endl;

                    if(iscancel==false)
                    {
                        if(node_found->cost > price){
                            cout<< stock_name << " " << price << " b" << endl;
                            ll.update(node_found,price);
                        }
                        else{
                            node_found->is_valid_ords=1;
                            node_found->ords=price;
                            cout<<"No Trade"<<endl;
                        }
                    }
                    else cout<<"No Trade"<<endl;
                }
            }
            else cout << "Unknown trade type: " << trade_type << endl;
        }
    }
}