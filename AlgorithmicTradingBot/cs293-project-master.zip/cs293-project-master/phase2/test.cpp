#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

struct Asset {
    std::string name;
    int quantity;
};

struct Deal {
    int timestamp;
    std::string company;
    std::string action;
    std::vector<Asset> assets;
    std::string P1;
    std::string Q1;
    int quantityDeal;
    int price;
    int endTime;
};

void parseString(const std::string& input, Deal& deal) {
    istringstream iss(input);

    iss >> deal.timestamp;
    iss >> deal.company >> deal.action;

    string token;
    while (iss >> token) {
        if (token[0] == '$') {
            // Stop parsing assets after encountering '$'
            deal.P1=token;
            break;
        } else {
            // Asset and its quantity
            Asset asset;
            asset.name = token;
            // Check if the next token is a numerical value
            if (iss >> asset.quantity) {
                deal.assets.push_back(asset);
            } else {
                // If no numerical value is provided, default to 1
                asset.quantity = 1;
                deal.assets.push_back(asset);
                // Since we didn't consume the non-numerical token, we need to clear the error state
                iss.clear();
            }
        }
    }
    
   // Continue parsing conventionally
iss >> deal.Q1 >> deal.endTime;
if(!deal.P1.empty()) deal.price = std::stoi(deal.P1.substr(1));
if(!deal.Q1.empty())deal.quantityDeal = std::stoi(deal.Q1.substr(1));
 
}


int main() {
    std::ifstream inputFile("output.txt");

    if (!inputFile.is_open()) {
        std::cerr << "Error opening the file.\n";
        return 1;
    }

    std::string line;
    bool parsingEnabled = false;

    while (std::getline(inputFile, line) && line != "!@") {
        // Check if the line starts with "TL"
        if (line.find("TL") == 0) {
            parsingEnabled = true;
            continue;
        }

        if (parsingEnabled && line.find("!@") != 0) {
            Deal deal;
            parseString(line, deal);

            // Display parsed information
            // std::cout << "Deal Information:\n";
              // Display parsed information
    std::cout << "Deal Information:\n";
    std::cout << "time stamp: " << deal.timestamp << " ";
    std::cout << "Company: " << deal.company << " ";
    std::cout << "Action: " << deal.action << " ";
    std::cout << "Assets:";
    for (const auto& asset : deal.assets) {
        std::cout << "  " << asset.name << ": " << asset.quantity << " ";
    }
    std::cout << "Price: " << deal.price << " ";
    std::cout << "Quantity Deal: " << deal.quantityDeal << " ";
    std::cout << "End Time: " << deal.endTime << "\n";

        }
    }

    inputFile.close();

    return 0;
}
