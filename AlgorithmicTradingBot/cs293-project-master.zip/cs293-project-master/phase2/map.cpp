#include<iostream>
#include<vector>
#include<string>
using namespace std;
class combo{public:
    string companyName;
    string tradeType;
    // int stock_quantity;
    int price;
    int qty;
    int timestamp;
    int expiry;
    combo* next;
    combo(int ts,string com,string tt,int p,int q,int e){
        companyName=com;
        tradeType=tt;
        timestamp=ts;
        // stock_quantity=sq;
        price=p;
        qty=q;
        expiry=e;
        next=NULL;
    }
};
template<typename T>
class LL{public:
    T* head;
    T* tail;//only in map
    int size;
    LL(){
        head=tail=NULL;
        size=0;
    }
    void insert(T* new_node){           //only for maps
        if(head==NULL){
            head=tail=new_node;
            size++;
            return;
        }
        tail->next=new_node;
        tail=new_node;
        size++;
    }
    void insertbuyorder(T*new_node){
        size++;
        if(head==NULL){
            head=new_node;
            return;
        }
        if(head->price < new_node->price){
            new_node->next=head;
            head=new_node;
            return;
        }
        T*prev=head;
        while(prev->next!=NULL){
            if(prev->next->price < new_node->price) break;                    
            prev=prev->next;
        }
        new_node->next=prev->next;
        prev->next=new_node;
    }
    void insertsellorder(T*new_node){
        size++;
        if(head==NULL) {
            head=new_node;
            return;
        }
        if(head->price > new_node->price){
            new_node->next=head;
            head=new_node;
            return;
        }
        T*prev=head;
        while(prev->next!=NULL){
            if(prev->next->price > new_node->price) break;                    
            prev=prev->next;
        }
        new_node->next=prev->next;
        prev->next=new_node;
    }
    T* find(string n){                 //only for searching in map
        T*curr=head;
        while(curr!=NULL){
            if(curr->key==n){
                return curr;
            }
            curr=curr->next;
        }
        return NULL;
    }
    void delOrder(T*to_be){
        if(head==NULL) return;
        if(head==to_be){
            head=to_be->next;
            delete(to_be);
            size--;
            return;
        }
        T*curr=head;
        while(curr->next!=NULL && curr->next!=to_be) curr=curr->next;
        if(curr->next==NULL) return;
        else {
            curr->next=to_be->next;
            delete(to_be);
            size--;
        }
    }
    void del(string k){                //for deleting one particular stock from the map
        if(head==NULL) return;
        T*curr=head;
        if(curr->key==k){
            if(head==tail){
                delete(head);
                size--;
                head=tail=NULL;
                return;
            }
            delete(head);
            size--;
            head=curr->next;
            return;
        }
        while(curr!=NULL && curr->next!=NULL){
            if(curr->next->key==k){
                T*to_be=curr->next;
                curr->next=to_be->next;
                if(to_be==tail){
                    tail=curr;
                }
                delete(to_be);
                size--;
                break;
            }
            curr=curr->next;
        }
    }
    void prin(){
        T*curr=head;
        while(curr!=NULL){
            curr->print();
            curr=curr->next;
        }
    }
};
template<typename K,typename V>
class KeyValue{public:
    K key;//STOCKNAME
    LL<V> Buyorders;
    LL<V> Sellorders;
    vector<V> comdata;
    KeyValue<K,V>* next;
    KeyValue(K st){
        key=st;
        Buyorders.head=Buyorders.tail=NULL;
        Sellorders.head=Sellorders.tail=NULL;
        next=NULL;
    }
    void print(){
        V* curr=Buyorders.head;
        while(curr!=NULL){
            cout<<curr->timestamp<<" "<<curr->companyName<<" "<<curr->tradeType<<" "<<key<<" "<<curr->price<<" "<<curr->qty<<" "<<curr->expiry<<endl;
            curr=curr->next;
        }
        curr=Sellorders.head;
        while(curr!=NULL){
            cout<<curr->timestamp<<" "<<curr->companyName<<" "<<curr->tradeType<<" "<<key<<" "<<curr->price<<" "<<curr->qty<<" "<<curr->expiry<<endl;
            curr=curr->next;
        }
    }
};
template<typename K,typename V>
class CustomUnorderedMap{public:
    vector<LL<KeyValue<K,V>>> table;
    size_t capacity;

    // A simple hash function for string keys
    size_t hash(const K& key) const {
        std::hash<string> hasher;
        return hasher(key) % capacity;
    }


    CustomUnorderedMap(size_t initialCapacity = 64){
        capacity=initialCapacity;
        table.resize(capacity);
        for(int i=0;i<capacity;i++){
            table[i].head = table[i].tail = NULL;
        }
    }

    // Retrieve the value associated with a key
    KeyValue<K, V>* operator[](const K &key) {              //map["ASML"] returns a pointer to KeyValue of "ASML" stock
        size_t index = hash(key);
        auto x = table[index].find(key);                     //returns a pointer to the keyvalue pair else NULL
        if (x == NULL) {
            KeyValue<K, V> *newPair=new KeyValue<K,V> (key);
            table[index].insert(newPair);                    //LL ka insert call ho gya to ye jo newPair h ye table[index] ke end me gya hoga
            return table[index].tail;
        } else {
            return x;
        }
    }

    // vector<int> contains(const K&key){
    //     size_t index = hash(key);
    //     auto x = table[index].find(key);                     //returns a pointer to the keyvalue pair else NULL
    //     if (x == NULL) {
    //         return table[index].tail;
    //     } else {
    //         return x;
    //     }
    // }
    // Remove a key-value pair from the map
    void erase(const K key) {
        size_t index = hash(key);
        table[index].del(key);
    }
    void print(){
        for(int i=0;i<capacity;i++){
            LL<KeyValue<K,V>> curr=table[i];
            curr.prin();
        }
    }
};
// int main(){
//     // KeyValue<string,combo> k1("ASML");
//     // combo *temp=new combo(0,"K","BUY",10,120,2,-1);
//     // k1.Buyorders.insertbuyorder(temp);
//     // temp=new combo(0,"K","SELL",10,120,2,-1);
//     // k1.Sellorders.insertsellorder(temp);
//     // temp=new combo(0,"K","SELL",10,110,2,-1);
//     // k1.Sellorders.insertsellorder(temp);
//     // KeyValue<string,combo> k2("ASML");
//     // temp=new combo(0,"KG","BUY",10,120,2,-1);
//     // k2.Buyorders.insertbuyorder(temp);
//     // temp=new combo(0,"K","BUY",10,120,2,-1);
//     // k2.Buyorders.insertbuyorder(temp);
//     // temp=new combo(0,"K","SELL",10,120,2,-1);
//     // k2.Sellorders.insertsellorder(temp);
//     // temp=new combo(0,"K","SELL",10,110,2,-1);
//     // k2.Sellorders.insertsellorder(temp);
//     // string s="K";
//     // string t="BUY";
//     // combo*c=new combo(0,s,t,110,2,-1);
//     // combo*d=new combo(0,"Kargo","BUY",110,2,-1);
//     // CustomUnorderedMap<string,combo> map;
//     // // map["ASML"]->Buyorders.insertbuyorder(c);     //only this is the way to access stocks nothing else
//     // // map["ASML"]->Buyorders.insertbuyorder(d);
//     // // combo*e=new combo(0,"K","BUY",10,110,2,-1);
//     // // map["AAPL"]->Buyorders.insertbuyorder(e);
    
//     // map["ASML"]->Buyorders.insertbuyorder(c);
//     // map["ASML"]->Buyorders.insertbuyorder(d);
//     // // // map.insert(k1);
//     // // // map.insert(k2);
//     // // // map["AAAPL"]=k2;
//     // // map.print();
//     // // map["ASML"]->Buyorders.delOrder(d);
//     // // map["ASML"]->Buyorders.delOrder(c);
//     // // map["ASML"];
//     // // map.erase("ASML");
//     // cout<<map["ASML"]->Buyorders.size<<endl;
//     // map.print();
//     // map["ASML"]->Buyorders.delOrder(c);
//     // cout<<map["ASML"]->Buyorders.size<<endl;
//     // map.print();
//     CustomUnorderedMap<string,node> companybook;
//     node*y=new node(1);
//     companybook["KarGO"]->comdata.insert(y);
//     y=new node(2);
//     companybook["KarGO"]->comdata.insert(y);
//     y=new node(3);
//     companybook["KarGO"]->comdata.insert(y);
//     y=new node(1);
//     companybook["KG"]->comdata.insert(y);
//     y=new node(1);
//     companybook["KG"]->comdata.insert(y);
//     y=new node(1);
//     companybook["KG"]->comdata.insert(y);
//     // cout<<companybook["KarGO"]->comdata.head->data<<endl;
//     // cout<<companybook["KarGO"]->comdata.head->next->data<<endl;
//     // cout<<companybook["KarGO"]->comdata.head->next->next->data<<endl;
//     // cout<<companybook["KarGO"]->comdata.head->data<<endl;
//     // cout<<companybook["KarGO"]->comdata.head->next->data<<endl;
//     // cout<<companybook["KarGO"]->comdata.head->next->next->data<<endl;

//     for(int i=0;i<companybook.capacity;i++){
//         auto curr=companybook.table[i].head;
//         while(curr!=NULL){
//             auto x=curr->comdata.head;
//             cout<<curr->key<<" ";
//             cout<<x->data<<" ";
//             cout<<x->next->data<<" ";
//             cout<<x->next->next->data<<" ";
//             curr=curr->next;
//         }
//     }
//     return 0;
// }